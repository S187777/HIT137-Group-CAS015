# Step 1: Open the CSV file so we can read its content
csv_file = open('input_file.csv', 'r')  # 'r' means we're opening it to read

# Step 2: Open the text file so we can write into it
text_file = open('output_file.txt', 'w')  # 'w' means we're opening it to write

# Step 3: Copy each line (row) from the CSV file
for line in csv_file:
    # Step 4: Paste (write) that line into the text file
    text_file.write(line)

# Step 5: Close both files to save changes
csv_file.close()
text_file.close()

